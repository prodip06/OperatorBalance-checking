package com.phone.balancecheker;

import com.revmob.RevMob;
import com.revmob.RevMobAdsListener;
import com.revmob.ads.banner.RevMobBanner;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class IMEIActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Button b;
		final TextView devid;
		setContentView(R.layout.imei_main);
		startRevMobSession();
		b = (Button) findViewById(R.id.buttonim);
		devid = (TextView) findViewById(R.id.textView1);
		

		
		
		
		/*	b.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View view) {

				int currentapiVersion = android.os.Build.VERSION.SDK_INT;
				if (currentapiVersion > android.os.Build.VERSION_CODES.KITKAT) {

				TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		        	tm.getDeviceId();
					
				} 
                 else {

				final TelephonyManager tm = (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);

				String android_id = tm.getDeviceId().toString();
				devid.setText(android_id);
				}

			}
		});*/
		
		
		
		
		
		
		
		
		

		b.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View view) {
				final TelephonyManager tm = (TelephonyManager) getBaseContext()
						.getSystemService(Context.TELEPHONY_SERVICE);

				String android_id = tm.getDeviceId().toString();
				devid.setText(android_id);

			}
		});

	}

	// /////////////////Prodip/////////////////////

	RevMob revmob;
	Activity currentActivity;
	RevMobBanner banner;

	public void startRevMobSession() {
		currentActivity = this;

		revmob = RevMob.startWithListener(currentActivity,
				new RevMobAdsListener() {
					@Override
					public void onRevMobSessionIsStarted() {
						super.onRevMobSessionIsStarted();
						loadStartingAds();
					}

					@Override
					public void onRevMobSessionNotStarted(String message) {
						startRevMobSession();
					}
				});

		loadStartingAds();
	}

	public void loadStartingAds() {
		showBanner();
	}

	ViewGroup viewGroup;

	void showBanner() {
		banner = revmob.createBanner(currentActivity);
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				viewGroup = (ViewGroup) findViewById(R.id.banner);
				viewGroup.removeAllViews();
				viewGroup.addView(banner);
			}
		});
	}

	// /////////////////////////////////

}
