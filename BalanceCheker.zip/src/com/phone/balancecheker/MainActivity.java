package com.phone.balancecheker;

import com.revmob.RevMob;
import com.revmob.RevMobAdsListener;
import com.revmob.ads.banner.RevMobBanner;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class MainActivity extends Activity implements View.OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		startRevMobSession();
		Button one = (Button) findViewById(R.id.button1);
		one.setOnClickListener(this); // calling onClick() method
		Button two = (Button) findViewById(R.id.button2);
		two.setOnClickListener(this);
		Button three = (Button) findViewById(R.id.button3);
		three.setOnClickListener(this);

		Button four = (Button) findViewById(R.id.button4);
		four.setOnClickListener(this); // calling onClick() method
		Button five = (Button) findViewById(R.id.button5);
		five.setOnClickListener(this);
		Button six = (Button) findViewById(R.id.button6);
		six.setOnClickListener(this);

		Button seven = (Button) findViewById(R.id.button7);
		seven.setOnClickListener(this); // calling onClick() method
		Button eight = (Button) findViewById(R.id.button8);
		eight.setOnClickListener(this);
		Button ten = (Button) findViewById(R.id.button10);
		ten.setOnClickListener(this);
		Button eleven = (Button) findViewById(R.id.button11);
		eleven.setOnClickListener(this);
		
		Button help1 = (Button) findViewById(R.id.button12);
		help1.setOnClickListener(this);
		Button help2 = (Button) findViewById(R.id.button13);
		help2.setOnClickListener(this);
		Button help3 = (Button) findViewById(R.id.button14);
		help3.setOnClickListener(this);
		Button help4 = (Button) findViewById(R.id.button15);
		help4.setOnClickListener(this);
		Button help5 = (Button) findViewById(R.id.button16);
		help5.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {

        case R.id.button1:
       	 
        
    		/*Intent intent = new Intent(Intent.ACTION_CALL);
        	intent.setPackage("com.android.phone"); 
	    	intent.setData(Uri.parse("tel:*2" + Uri.encode("#")));
	    	startActivity(intent); */
	    	
	    	
	    	int currentapiVersion = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent = new Intent(Intent.ACTION_CALL);
	        	intent.setPackage("com.android.phone"); 
		    	intent.setData(Uri.parse("tel:*2" + Uri.encode("#")));
		    	startActivity(intent); 
				
			} 
             else {

            		Intent intent = new Intent(Intent.ACTION_CALL);
            		intent.setPackage("com.android.server.telecom");
        	    	intent.setData(Uri.parse("tel:*2" + Uri.encode("#")));
        	    	startActivity(intent); 
			}
	    	
            break;

        case R.id.button2:
 
        	int currentapiVersion1 = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion1 <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent1 = new Intent(Intent.ACTION_CALL);
	        	intent1.setPackage("com.android.phone"); 
	        	intent1.setData(Uri.parse("tel:*566" + Uri.encode("#")));
		    	startActivity(intent1); 
				
			} 
             else {

            		Intent intent1 = new Intent(Intent.ACTION_CALL);
            		intent1.setPackage("com.android.server.telecom");
            		intent1.setData(Uri.parse("tel:*566" + Uri.encode("#")));
        	    	startActivity(intent1); 
			}
        	
            break;

            
            
            
            
        case R.id.button3:
        	
        	
        	
        	
        	int currentapiVersion2 = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion2 <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent2 = new Intent(Intent.ACTION_CALL);
	        	intent2.setPackage("com.android.phone"); 
	        	intent2.setData(Uri.parse("tel:*511" + Uri.encode("#")));
		    	startActivity(intent2); 
				
			} 
             else {

            		Intent intent2 = new Intent(Intent.ACTION_CALL);
            		intent2.setPackage("com.android.server.telecom");
            		intent2.setData(Uri.parse("tel:*511" + Uri.encode("#")));
        	    	startActivity(intent2); 
			}
        	//Intent intent2 = new Intent(Intent.ACTION_DIAL);
	    	//intent2.setData(Uri.parse("tel:*511" + Uri.encode("#")));
	    	//startActivity(intent2); 

            break;
            
        case R.id.button4:

        	
         	int currentapiVersion3 = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion3 <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent3 = new Intent(Intent.ACTION_CALL);
	        	intent3.setPackage("com.android.phone"); 
	        	intent3.setData(Uri.parse("tel:*124" + Uri.encode("#")));
		    	startActivity(intent3); 
				
			} 
             else {

            		Intent intent3 = new Intent(Intent.ACTION_CALL);
            		intent3.setPackage("com.android.server.telecom");
            		intent3.setData(Uri.parse("tel:*124" + Uri.encode("#")));
        	    	startActivity(intent3); 
			}
        	
        	
        	
         	//Intent intent3 = new Intent(Intent.ACTION_DIAL);
	    	//intent3.setData(Uri.parse("tel:*124" + Uri.encode("#")));
	    	//startActivity(intent3); 
			
            break;

        case R.id.button5:
        	
          	int currentapiVersion4 = android.os.Build.VERSION.SDK_INT;
        			if (currentapiVersion4 <= android.os.Build.VERSION_CODES.KITKAT) {

        				Intent intent4 = new Intent(Intent.ACTION_CALL);
        	        	intent4.setPackage("com.android.phone"); 
        	        	intent4.setData(Uri.parse("tel:*140*2*4" + Uri.encode("#")));
        		    	startActivity(intent4); 
        				
        			} 
                     else {

                    		Intent intent4 = new Intent(Intent.ACTION_CALL);
                    		intent4.setPackage("com.android.server.telecom");
                    		intent4.setData(Uri.parse("tel:*140*2*4" + Uri.encode("#")));
                	    	startActivity(intent4); 
        			}
        	
         	//Intent intent4 = new Intent(Intent.ACTION_DIAL);
	    	//intent4.setData(Uri.parse("tel:*140*2*4" + Uri.encode("#")));
	    	//startActivity(intent4); 

            break;

        case R.id.button6:
        	
        	
        	
          	int currentapiVersion5 = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion5 <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent5 = new Intent(Intent.ACTION_CALL);
	        	intent5.setPackage("com.android.phone"); 
	        	intent5.setData(Uri.parse("tel:*222" + Uri.encode("#")));
		    	startActivity(intent5); 
				
			} 
             else {

            		Intent intent5 = new Intent(Intent.ACTION_CALL);
            		intent5.setPackage("com.android.server.telecom");
            		intent5.setData(Uri.parse("tel:*222" + Uri.encode("#")));
        	    	startActivity(intent5); 
			}
        	
         	//Intent intent5 = new Intent(Intent.ACTION_DIAL);
	    	//intent5.setData(Uri.parse("tel:*222" + Uri.encode("#")));
	    	//startActivity(intent5); 

            break;
            
        case R.id.button7:
        	
        	
         	int currentapiVersion6 = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion6 <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent6 = new Intent(Intent.ACTION_CALL);
	        	intent6.setPackage("com.android.phone"); 
	        	intent6.setData(Uri.parse("tel:*121*6*3" + Uri.encode("#")));
		    	startActivity(intent6); 
				
			} 
             else {

            		Intent intent6 = new Intent(Intent.ACTION_CALL);
            		intent6.setPackage("com.android.server.telecom");
            		intent6.setData(Uri.parse("tel:*121*6*3" + Uri.encode("#")));
        	    	startActivity(intent6); 
			}
        	
        	
         	//Intent intent6 = new Intent(Intent.ACTION_DIAL);
	    	//intent6.setData(Uri.parse("tel:*121*6*3" + Uri.encode("#")));
	    	//startActivity(intent6); 

            break;

        case R.id.button8:
        	
        	
          	int currentapiVersion7 = android.os.Build.VERSION.SDK_INT;
        			if (currentapiVersion7 <= android.os.Build.VERSION_CODES.KITKAT) {

        				Intent intent7 = new Intent(Intent.ACTION_CALL);
        	        	intent7.setPackage("com.android.phone"); 
        	        	intent7.setData(Uri.parse("tel:*778" + Uri.encode("#")));
        		    	startActivity(intent7); 
        				
        			} 
                     else {

                    		Intent intent7 = new Intent(Intent.ACTION_CALL);
                    		intent7.setPackage("com.android.server.telecom");
                    		intent7.setData(Uri.parse("tel:*778" + Uri.encode("#")));
                	    	startActivity(intent7); 
        			}
                	
        	
         	//Intent intent7 = new Intent(Intent.ACTION_DIAL);
	    	//intent7.setData(Uri.parse("tel:*778" + Uri.encode("#")));
	    	//startActivity(intent7); 

            break;

        case R.id.button11:
        	int currentapiVersion9 = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion9 <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent8 = new Intent(Intent.ACTION_CALL);
	        	intent8.setPackage("com.android.phone"); 
	        	intent8.setData(Uri.parse("tel:*152" + Uri.encode("#")));
		    	startActivity(intent8); 
				
			} 
             else {

            		Intent intent8 = new Intent(Intent.ACTION_CALL);
            		intent8.setPackage("com.android.server.telecom");
            		intent8.setData(Uri.parse("tel:*152" + Uri.encode("#")));
        	    	startActivity(intent8); 
			}
        	
        	
        	
         	//Intent intent8 = new Intent(Intent.ACTION_DIAL);
	    	//intent8.setData(Uri.parse("tel:*152" + Uri.encode("#")));
	    	//startActivity(intent8); 

            break;
        case R.id.button10:
        	int currentapiVersion10 = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion10 <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent9 = new Intent(Intent.ACTION_CALL);
	        	intent9.setPackage("com.android.phone"); 
	        	intent9.setData(Uri.parse("tel:*551" + Uri.encode("#")));
		    	startActivity(intent9); 
				
			} 
             else {

            		Intent intent9 = new Intent(Intent.ACTION_CALL);
            		intent9.setPackage("com.android.server.telecom");
            		intent9.setData(Uri.parse("tel:*551" + Uri.encode("#")));
        	    	startActivity(intent9); 
			}
        	
        	
         	//Intent intent9 = new Intent(Intent.ACTION_DIAL);
	    	//intent9.setData(Uri.parse("tel:*551" + Uri.encode("#")));
	    	//startActivity(intent9); 
            break;
            
            
            
            
        case R.id.button12:
        	
          	int currentapiVersion11 = android.os.Build.VERSION.SDK_INT;
    			if (currentapiVersion11 <= android.os.Build.VERSION_CODES.KITKAT) {

    				Intent intent10 = new Intent(Intent.ACTION_CALL);
    	        	intent10.setPackage("com.android.phone"); 
    	        	intent10.setData(Uri.parse("tel:121"));
    		    	startActivity(intent10); 
    				
    			} 
                 else {

                		Intent intent10 = new Intent(Intent.ACTION_CALL);
                		intent10.setPackage("com.android.server.telecom");
                		intent10.setData(Uri.parse("tel:121"));
            	    	startActivity(intent10); 
    			}
            	
        	
        	
        	
         	//Intent intent10 = new Intent(Intent.ACTION_DIAL);
	    	//intent10.setData(Uri.parse("tel:121"));
	    	//startActivity(intent10); 
	    	
            break;
            
        case R.id.button13:
        	int currentapiVersion12 = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion12 <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent11 = new Intent(Intent.ACTION_CALL);
	        	intent11.setPackage("com.android.phone"); 
	        	intent11.setData(Uri.parse("tel:121"));
		    	startActivity(intent11); 
				
			} 
             else {

            		Intent intent11 = new Intent(Intent.ACTION_CALL);
            		intent11.setPackage("com.android.server.telecom");
            		intent11.setData(Uri.parse("tel:121"));
        	    	startActivity(intent11); 
			}
         	//Intent intent11 = new Intent(Intent.ACTION_DIAL);
	    	//intent11.setData(Uri.parse("tel:121"));
	    	//startActivity(intent11); 
            break;
            
        case R.id.button14:
        	int currentapiVersion13 = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion13 <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent12 = new Intent(Intent.ACTION_CALL);
	        	intent12.setPackage("com.android.phone"); 
	        	intent12.setData(Uri.parse("tel:123"));
		    	startActivity(intent12); 
				
			} 
             else {

            		Intent intent12 = new Intent(Intent.ACTION_CALL);
            		intent12.setPackage("com.android.server.telecom");
            		intent12.setData(Uri.parse("tel:123"));
        	    	startActivity(intent12); 
			}
        	
        	
        	
         	//Intent intent12 = new Intent(Intent.ACTION_DIAL);
	    	//intent12.setData(Uri.parse("tel:123"));
	    	//startActivity(intent12); 
            break;
        case R.id.button15:
        	
         	int currentapiVersion14 = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion14 <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent13 = new Intent(Intent.ACTION_CALL);
	        	intent13.setPackage("com.android.phone"); 
	        	intent13.setData(Uri.parse("tel:121"));
		    	startActivity(intent13); 
				
			} 
             else {

            		Intent intent13 = new Intent(Intent.ACTION_CALL);
            		intent13.setPackage("com.android.server.telecom");
            		intent13.setData(Uri.parse("tel:121"));
        	    	startActivity(intent13); 
			}
        	
        	
        	
         	//Intent intent13 = new Intent(Intent.ACTION_DIAL);
	    	//intent13.setData(Uri.parse("tel:121"));
	    	//startActivity(intent13); 
            break;
        case R.id.button16:
        	
        	
        	int currentapiVersion15 = android.os.Build.VERSION.SDK_INT;
			if (currentapiVersion15 <= android.os.Build.VERSION_CODES.KITKAT) {

				Intent intent14 = new Intent(Intent.ACTION_CALL);
	        	intent14.setPackage("com.android.phone"); 
	        	intent14.setData(Uri.parse("tel:121"));
		    	startActivity(intent14); 
				
			} 
             else {

            		Intent intent14 = new Intent(Intent.ACTION_CALL);
            		intent14.setPackage("com.android.server.telecom");
            		intent14.setData(Uri.parse("tel:121"));
        	    	startActivity(intent14); 
			}
        	
        	
         	//Intent intent14 = new Intent(Intent.ACTION_DIAL);
	    	//intent14.setData(Uri.parse("tel:121"));
	    	//startActivity(intent14); 
            break;

		default:
			break;
		}

	}
	
	
	///////////////////....Prodip..../////////////////////

		RevMob revmob;
		Activity currentActivity;
		RevMobBanner banner;

		public void startRevMobSession() {
			currentActivity = this;

			revmob = RevMob.startWithListener(currentActivity,
					new RevMobAdsListener() {
						@Override
						public void onRevMobSessionIsStarted() {
							super.onRevMobSessionIsStarted();
							loadStartingAds();
						}

						@Override
						public void onRevMobSessionNotStarted(String message) {
							startRevMobSession();
						}
					});

			loadStartingAds();
		}

		public void loadStartingAds() {
			showBanner();
		}

		ViewGroup viewGroup;

		void showBanner() {
			banner = revmob.createBanner(currentActivity);
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					viewGroup = (ViewGroup) findViewById(R.id.banner);
					viewGroup.removeAllViews();
					viewGroup.addView(banner);
				}
			});
		}

		// ///////////......End.....//////////////////////
}
