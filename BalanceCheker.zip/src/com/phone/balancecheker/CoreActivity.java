package com.phone.balancecheker;


import com.revmob.RevMob;
import com.revmob.RevMobAdsListener;
import com.revmob.ads.banner.RevMobBanner;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class CoreActivity extends Activity implements View.OnClickListener{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.call_main);
		startRevMobSession();
		Button but = (Button) findViewById(R.id.btn);
		but.setOnClickListener(this);
		Button butimei = (Button) findViewById(R.id.buttonim);
		butimei.setOnClickListener(this);
	}

		/*but.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View view) {
				Intent i = new Intent(getApplicationContext(),
						MainActivity.class);
				startActivity(i);

			}
		});*/
		
		@Override
		public void onClick(View v) {
		switch (v.getId()) {

        case R.id.btn:
       	 
        	Intent i = new Intent(getApplicationContext(),
					MainActivity.class);
			startActivity(i); 
            break;

        case R.id.buttonim:
        	
        	
          	//Step 1:
        	/*Intent intenti = new Intent(Intent.ACTION_DIAL); 
	    	intenti.setData(Uri.parse("tel:*" + Uri.encode("#")+"06"+ Uri.encode("#")));
	    	startActivity(intenti); */
        	
        	Intent ii = new Intent(getApplicationContext(),
					IMEIActivity.class);
			startActivity(ii);
        	
        	
        	//Step 2:
        	/*TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        	tm.getDeviceId();*/
   	
        	
        	//Step 3:
        	/*startActivity(new Intent("android.intent.action.DIAL",Uri.parse("tel:*06" + Uri.encode("#"))));*/
        	
        	
        	//Step 4:
        	/*String encodedHash = Uri.encode("#");
        	String ussd = "*" + encodedHash + "06" + encodedHash;
        	startActivityForResult(new Intent("android.intent.action.DIAL",
        	Uri.parse("tel:" + ussd)), 1);*/
        	
        	
        	//Step 5:
        	/*sendBroadcast(new Intent("android.provider.Telephony.SECRET_CODE",Uri.parse("android_secret_code://" + "06")));*/
        	
        	
        	//Step 6:
            /*	String ussdCode = "*" +Uri.encode ("#")+ "06" + Uri.encode ("#");
            	startActivity (new Intent ("android.intent.action.DIAL", Uri.parse ("tel:" + ussdCode)));*/
        	
        	
        	//Step 7:
        	/*Intent oma = new Intent(Intent.ACTION_MAIN);
        	oma.setClassName("com.android.settings", "com.android.settings.TestingSettings");
            startActivity(oma);*/
            
        	
        
        	
        	
            break;
        
		default:
			break;
		}

	}
	
	



	private void runActivity(Intent intenti) {
			// TODO Auto-generated method stub
			
		}





	// /////////////////Prodip/////////////////////

	RevMob revmob;
	Activity currentActivity;
	RevMobBanner banner;

	public void startRevMobSession() {
		currentActivity = this;

		revmob = RevMob.startWithListener(currentActivity,
				new RevMobAdsListener() {
					@Override
					public void onRevMobSessionIsStarted() {
						super.onRevMobSessionIsStarted();
						loadStartingAds();
					}

					@Override
					public void onRevMobSessionNotStarted(String message) {
						startRevMobSession();
					}
				});

		loadStartingAds();
	}

	public void loadStartingAds() {
		showBanner();
	}

	ViewGroup viewGroup;

	void showBanner() {
		banner = revmob.createBanner(currentActivity);
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				viewGroup = (ViewGroup) findViewById(R.id.banner);
				viewGroup.removeAllViews();
				viewGroup.addView(banner);
			}
		});
	}


	// /////////////////////////////////

}
